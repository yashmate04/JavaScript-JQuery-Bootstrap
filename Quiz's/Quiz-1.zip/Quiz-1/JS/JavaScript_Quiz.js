// 1. 
let a = 10;
let b = 20;
console.log("Sum =", a + b);

// 2.
let length = 5;
let width = 4;

let area = length * width;
let perimeter = 2 * (length + width);

console.log("Area:", area);
console.log("Perimeter:", perimeter);

// 3.
let num = 7;

if (num % 2 === 0) {
    console.log("Even");
} else {
    console.log("Odd");
}

// 4.
let number = -5;

if (number > 0) {
    console.log("Positive");
} else if (number < 0) {
    console.log("Negative");
} else {
    console.log("Zero");
}

// 5.
let day = 2;

switch (day) {
    case 0: console.log("Sunday"); break;
    case 1: console.log("Monday"); break;
    case 2: console.log("Tuesday"); break;
    case 3: console.log("Wednesday"); break;
    case 4: console.log("Thursday"); break;
    case 5: console.log("Friday"); break;
    case 6: console.log("Saturday"); break;
    default: console.log("Invalid Day");
}

// 6.
for (let i = 1; i <= 50; i++) {
    console.log(i);
}

// 7.
let i = 1, sum = 0;
while (i <= 100) {
    sum += i;
    i++;
}
console.log("Sum =", sum);

// 8.
let pattern = "";
for (let i = 1; i <= 5; i++) {
    for (let j = 1; j <= i; j++) {
        pattern += "*";
    }
    pattern += "\n";
}
console.log(pattern);

// 9.
function greet(name) {
    return "Hello, " + name + "!";
}
console.log(greet("Yash"));

// 10.
function maxOfThree(a, b, c) {
    return Math.max(a, b, c);
}
console.log(maxOfThree(10, 25, 15));

// 11.
let str = "javascript";

console.log(str.toUpperCase());
console.log(str.length);
console.log(str.substring(2, 6));

// 12.
let student = {
    name: "Yash",
    age: 21,
    course: "BCA"
};
for (let key in student) {
    console.log(key + ": " + student[key]);
}

// 13.
student.display = function () {
    console.log(`Name: ${this.name}, Age: ${this.age}, Course: ${this.course}`);
};
student.display();

 // 14. 





// 15.
let date = new Date();
console.log("Date:", date.toDateString());
console.log("Month:", date.toLocaleString('default', { month: 'long' }));
console.log("Time:", date.toLocaleTimeString());

// 16.
let fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"];

fruits.push("Pineapple");
fruits.shift();
fruits.sort();

console.log(fruits);

// 17.
let arr = [5, 12, 8, 20, 3];
let max = arr[0];

for (let num of arr) {
    if (num > max) {
        max = num;
    }
}
console.log("Largest =", max);

// 18.
function countEven(arr) {
    let count = 0;
    for (let n of arr) {
        if (n % 2 === 0) count++;
    }
    return count;
}
console.log(countEven([2, 5, 6, 8, 9, 10]));

// 22.
let n = 5;

for (let i = 1; i <= 10; i++) {
    console.log(`${n} x ${i} = ${n * i}`);
}

// 23.
let text = "Hello";

for (let char of text) {
    console.log(char);
}

